<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\EventController;
use App\Http\Controllers\Api\AuthController;

// --- Rutas de Autenticación Públicas ---
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

// --- Rutas Protegidas (Requieren Token) ---
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    
    // Obtener usuario actual
    Route::get('/user', function (Request $request) {
        return $request->user();
    });

    // CREAR evento
    Route::post('/events', [EventController::class, 'store']);

    // EDITAR evento (NUEVO)
    Route::put('/events/{id}', [EventController::class, 'update']);

    // BORRAR evento (NUEVO)
    Route::delete('/events/{id}', [EventController::class, 'destroy']);
    
    // RUTAS DE COMENTARIOS
    Route::post('/events/{id}/comments', [App\Http\Controllers\Api\CommentController::class, 'store']);
    Route::delete('/comments/{id}', [App\Http\Controllers\Api\CommentController::class, 'destroy']);
});

// --- Rutas Públicas (Cualquiera puede verlas) ---
Route::get('/events', [EventController::class, 'index']); // Lista de eventos
Route::get('/events/{id}', [EventController::class, 'show']); // Detalle de un evento